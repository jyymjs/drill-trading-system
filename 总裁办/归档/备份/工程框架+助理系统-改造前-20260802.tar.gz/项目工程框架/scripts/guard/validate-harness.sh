#!/bin/bash
# validate-harness.sh — 框架完整性自检
echo "🔍 === 框架自检 ==="

FAIL=0
check() { if [ -e "$1" ]; then echo "  ✅ $1"; else echo "  ❌ 缺失: $1"; FAIL=1; fi }

echo "--- 核心文件 ---"
check "CLAUDE.md"
check ".claude/settings.json"
check ".gitignore"

echo "--- 规则 ---"
check "rules/00-core.md"
check "rules/01-language.md"
check "rules/02-git.md"
check "rules/03-security.md"
check "rules/04-quality.md"
check "rules/05-architecture.md"
check "rules/reviewer-criteria.md"

echo "--- 角色定义 ---"
check "agents/planner.md"
check "agents/executor.md"
check "agents/reviewer.md"
check "agents/optimizer.md"

echo "--- 门禁脚本 ---"
check "scripts/guard/gatekeeper.sh"
check "scripts/guard/validate-harness.sh"
check "scripts/guard/task-counter.sh"

echo "--- 模板与运行文档 ---"
check "templates/project-CLAUDE.md"
check "templates/skill-SKILL.md"
check "templates/project-init.sh"
check "docs/audit/regression-log.md"
check "docs/audit/last-optimization.txt"
check "docs/changelog.md"

echo "--- 技能完整性 ---"
SKILL_DIR=".claude/skills"
EXPECTED_COUNT=$(ls -d "$SKILL_DIR"/*/ 2>/dev/null | wc -l | tr -d ' ')
ACTUAL_COUNT=0
MISSING_ROLE_SKILLS=""
for d in "$SKILL_DIR"/*/; do
  [ -d "$d" ] || continue
  name=$(basename "$d")
  if [ -f "$d/SKILL.md" ]; then
    ACTUAL_COUNT=$((ACTUAL_COUNT + 1))
  else
    echo "  ❌ $name 缺 SKILL.md"
    FAIL=1
  fi
done
if [ "$ACTUAL_COUNT" -eq "$EXPECTED_COUNT" ]; then
  echo "  ✅ 全部 $EXPECTED_COUNT 个技能就位"
else
  echo "  ❌ 技能数: $ACTUAL_COUNT / $EXPECTED_COUNT"
  FAIL=1
fi

echo "--- 角色引用技能验证 ---"
# 自动解析 agents/*.md 的"核心：/辅助："行提取技能清单——agents 文档为唯一事实源，无需手工同步
ROLE_SKILLS=""
for f in agents/*.md; do
  role_skills=$(grep -oE "^(核心|辅助)：.*" "$f" | sed 's/^[^：]*：//' | tr '、' '\n' | grep -oE '^[a-z][a-z-]*')
  ROLE_SKILLS="$ROLE_SKILLS $role_skills"
done
MISSING_COUNT=0
for skill in $ROLE_SKILLS; do
  if [ ! -d "$SKILL_DIR/$skill" ]; then
    echo "  ❌ 角色引用了不存在的技能: $skill"
    FAIL=1
    MISSING_COUNT=$((MISSING_COUNT + 1))
  fi
done
# 检查是否有技能未被任何角色引用
for d in "$SKILL_DIR"/*/; do
  [ -d "$d" ] || continue
  skill=$(basename "$d")
  found=0
  for rs in $ROLE_SKILLS; do
    [ "$rs" = "$skill" ] && found=1 && break
  done
  if [ "$found" -eq 0 ]; then
    echo "  ⚠ 技能未被任何角色引用: $skill"
  fi
done
if [ "$MISSING_COUNT" -eq 0 ]; then
  echo "  ✅ 所有角色引用技能均存在"
fi

echo "--- 空目录检查 ---"
EMPTY_DIRS=$(find . -type d -empty 2>/dev/null | grep -v '.git' | head -10)
if [ -n "$EMPTY_DIRS" ]; then
  echo "  ⚠ 存在空目录（可能缺 .gitkeep）:"
  echo "$EMPTY_DIRS" | while read d; do echo "    $d"; done
else
  echo "  ✅ 无空目录"
fi

echo "--- 残留检测 ---"
OPENAI_COUNT=$(find . -name "openai.yaml" 2>/dev/null | wc -l)
if [ "$OPENAI_COUNT" -gt 0 ]; then
  echo "  ❌ 残留 $OPENAI_COUNT 个 openai.yaml"
  FAIL=1
else
  echo "  ✅ 无 openai.yaml 残留"
fi

echo ""
if [ "$FAIL" -eq 0 ]; then
  echo "✅ 框架完整 ($ACTUAL_COUNT 技能, 4 角色, 6 规则)"
else
  echo "❌ 存在 $FAIL 项问题，请修复"
  exit 1
fi
